const express = require('express');
const Terminology = require('../../models/Terminology');
const { syncFromOrphadata, isExternalTerminologySyncEnabled } = require('../../services/terminologySync.service');
const logger = require('../../utils/logger');

const router = express.Router();
const ORPHADATA_BASE_URL = (process.env.ORPHADATA_BASE_URL || '').replace(/\/$/, '');

function normalizeText(value) {
  return String(value || '').trim();
}

function splitCodes(value) {
  return normalizeText(value)
    .split(/[;,|]/)
    .map((item) => normalizeText(item))
    .filter(Boolean);
}

function normalizeOrphaCode(value) {
  const raw = normalizeText(value);
  if (!raw) return '';
  return /^ORPHA:/i.test(raw) ? raw.replace(/^orpha:/i, 'ORPHA:') : `ORPHA:${raw}`;
}

function normalizeOmimCode(value) {
  const raw = normalizeText(value);
  if (!raw) return '';
  return /^OMIM:/i.test(raw) ? raw.replace(/^omim:/i, 'OMIM:') : `OMIM:${raw}`;
}

function getOrphaNumeric(value) {
  return normalizeOrphaCode(value).replace(/^ORPHA:/i, '');
}

function buildTerminologyFromCid(doc = {}) {
  const cidCode = normalizeText(doc.Codigos_CID10 || doc.cid10 || doc.Codigo_Tabulacao);
  const description = normalizeText(doc.Descricao || doc.descricao || doc.namePt || doc.nameEn || doc.nameEs);
  const aliases = [
    ...(Array.isArray(doc.aliases) ? doc.aliases : []),
    ...(Array.isArray(doc.synonyms) ? doc.synonyms : []),
    ...(Array.isArray(doc.alternativeNames) ? doc.alternativeNames : []),
  ].map((item) => normalizeText(item)).filter(Boolean);

  const orphaCodes = splitCodes(doc.ORPHA).map(normalizeOrphaCode).filter(Boolean);
  const omimCodes = splitCodes(doc.OMIM).map(normalizeOmimCode).filter(Boolean);

  return orphaCodes.map((orphaCode) => ({
    sistema: 'ORPHA',
    codigo: orphaCode,
    descricao: description || orphaCode,
    label: description || orphaCode,
    sinonimos: aliases,
    aliases,
    relacoes: {
      cid: cidCode,
      omim: omimCodes[0] || '',
      orpha: orphaCode,
      hpo: '',
    },
    ativo: doc.active !== false,
    sincronizadoEm: new Date(),
    lang: 'pt',
    fonte: 'local-cids-redundancy',
  }));
}

function buildTerminologyFromOrphanetDisease(doc = {}) {
  const rawCode = normalizeText(doc.code || doc.orphaCode || doc.ORPHA);
  const codigo = normalizeOrphaCode(rawCode);
  if (!codigo) {
    return null;
  }

  const description = normalizeText(doc.name || doc.label || doc.descricao);
  const synonyms = Array.isArray(doc.synonyms) ? doc.synonyms.map((item) => normalizeText(item)).filter(Boolean) : [];

  return {
    sistema: 'ORPHA',
    codigo,
    descricao: description || codigo,
    label: description || codigo,
    sinonimos: synonyms,
    aliases: synonyms,
    relacoes: {
      cid: '',
      omim: '',
      orpha: codigo,
      hpo: '',
    },
    ativo: true,
    sincronizadoEm: new Date(),
    lang: 'pt',
    fonte: 'local-orphanet-redundancy',
  };
}

async function bulkUpsertTerminologies(collection, records = []) {
  const validRecords = (Array.isArray(records) ? records : []).filter((item) => item && item.codigo && item.sistema && item.descricao);
  if (validRecords.length === 0) {
    return { upserted: 0 };
  }

  const operations = validRecords.map((item) => ({
    updateOne: {
      filter: { sistema: item.sistema, codigo: item.codigo },
      update: { $set: item },
      upsert: true,
    },
  }));

  await collection.bulkWrite(operations, { ordered: false });
  return { upserted: operations.length };
}

async function bulkUpsertOrphanetRedundancy(db, records = []) {
  const normalized = (Array.isArray(records) ? records : [])
    .filter((item) => String(item?.sistema || '').toUpperCase() === 'ORPHA')
    .map((item) => {
      const code = getOrphaNumeric(item.codigo || item.relacoes?.orpha || '');
      return code ? {
        code,
        name: normalizeText(item.descricao || item.label || item.codigo),
        synonyms: Array.isArray(item.aliases) ? item.aliases : [],
        lang: 'pt',
        source: normalizeText(item.fonte || 'terminologies-route') || 'terminologies-route',
        updatedAt: new Date(),
      } : null;
    })
    .filter(Boolean);

  if (normalized.length === 0) {
    return { upserted: 0 };
  }

  const operations = normalized.map((item) => ({
    updateOne: {
      filter: { code: item.code },
      update: { $set: item },
      upsert: true,
    },
  }));

  await db.collection('orphanet_diseases').bulkWrite(operations, { ordered: false });
  return { upserted: operations.length };
}

async function hydrateFromLocalRedundancy(db, { search, sistema, limit }) {
  const regex = new RegExp(search, 'i');
  const max = Math.min(Math.max(Number(limit) || 50, 1), 100);
  const records = [];

  if (!sistema || sistema === 'ORPHA') {
    const cids = await db.collection('cids').find({
      $or: [
        { ORPHA: regex },
        { OMIM: regex },
        { Codigos_CID10: regex },
        { Descricao: regex },
        { aliases: regex },
      ],
    }).limit(max).toArray();

    cids.forEach((doc) => {
      records.push(...buildTerminologyFromCid(doc));
    });

    if (records.length < max) {
      const orphanetDocs = await db.collection('orphanet_diseases').find({
        $or: [
          { code: regex },
          { name: regex },
          { synonyms: regex },
        ],
      }).limit(max).toArray();

      orphanetDocs.forEach((doc) => {
        const normalized = buildTerminologyFromOrphanetDisease(doc);
        if (normalized) {
          records.push(normalized);
        }
      });
    }
  }

  const dedupe = new Map();
  records.forEach((item) => {
    const key = `${item.sistema}::${item.codigo}`;
    if (!dedupe.has(key)) {
      dedupe.set(key, item);
    }
  });

  return Array.from(dedupe.values()).slice(0, max);
}

async function fetchJsonWithTimeout(url, timeoutMs = 12000) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    });

    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload?.message || payload?.error || `HTTP ${response.status}`);
    }

    return payload;
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error(`Timeout ao consultar Orphadata (${timeoutMs}ms)`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

function normalizeOrphaApiResult(item = {}) {
  const orpha = normalizeOrphaCode(item.ORPHAcode || item.orphaCode || item.orpha || item.codigo || item.code);
  if (!orpha) {
    return null;
  }

  const preferredTerm = normalizeText(item['Preferred term'] || item.preferredTerm || item.label || item.descricao || item.name);
  const extRefs = Array.isArray(item.ExternalReference) ? item.ExternalReference : [];
  const icd10 = normalizeText(extRefs.find((ref) => String(ref?.Source || '').toUpperCase() === 'ICD-10')?.Reference);
  const omim = normalizeText(extRefs.find((ref) => String(ref?.Source || '').toUpperCase() === 'OMIM')?.Reference);
  const synonymValues = Array.isArray(item.Synonym)
    ? item.Synonym.map((entry) => normalizeText(entry?.label || entry?.Label || entry?._ || entry)).filter(Boolean)
    : [];

  return {
    sistema: 'ORPHA',
    codigo: orpha,
    descricao: preferredTerm || orpha,
    label: preferredTerm || orpha,
    sinonimos: synonymValues,
    aliases: synonymValues,
    relacoes: {
      cid: icd10,
      hpo: '',
      omim: normalizeOmimCode(omim),
      orpha,
    },
    ativo: true,
    sincronizadoEm: new Date(),
    lang: 'en',
    fonte: 'orphadata-live',
  };
}

async function hydrateFromOrphadata(search, limit) {
  if (!isExternalTerminologySyncEnabled()) {
    return [];
  }
  if (!ORPHADATA_BASE_URL) {
    return [];
  }

  const term = normalizeText(search);
  if (!term) {
    return [];
  }

  const numericOrpha = normalizeText(term).replace(/^ORPHA:/i, '');
  const requests = [
    `${ORPHADATA_BASE_URL}/rd-cross-referencing/orphacodes/names/${encodeURIComponent(term)}`,
  ];

  if (/^\d+$/.test(numericOrpha)) {
    requests.unshift(`${ORPHADATA_BASE_URL}/rd-cross-referencing/orphacodes/${encodeURIComponent(numericOrpha)}`);
  }

  const collected = [];
  for (const url of requests) {
    try {
      const payload = await fetchJsonWithTimeout(url);
      const data = payload?.data?.results;
      if (Array.isArray(data)) {
        collected.push(...data);
      } else if (data && typeof data === 'object') {
        collected.push(data);
      }
    } catch (error) {
      logger.warn(`Falha no fallback Orphadata (${url}): ${error.message}`);
    }
  }

  const normalized = collected
    .map((item) => normalizeOrphaApiResult(item))
    .filter(Boolean);

  const dedupe = new Map();
  normalized.forEach((item) => {
    const key = `${item.sistema}::${item.codigo}`;
    if (!dedupe.has(key)) {
      dedupe.set(key, item);
    }
  });

  return Array.from(dedupe.values()).slice(0, limit);
}

function formatTerminology(terminology) {
  return {
    id: String(terminology._id),
    codigo: terminology.codigo,
    sistema: terminology.sistema,
    descricao: terminology.descricao,
    label: terminology.label || terminology.descricao,
    lang: terminology.lang || '',
    sinonimos: Array.isArray(terminology.sinonimos) ? terminology.sinonimos : [],
    aliases: Array.isArray(terminology.aliases) ? terminology.aliases : [],
    relacoes: terminology.relacoes || {},
    ativo: Boolean(terminology.ativo),
    sincronizadoEm: terminology.sincronizadoEm,
  };
}

router.get('/', async (req, res) => {
  try {
    const db = req.app.locals.db;
    if (!db) {
      return res.status(503).json({ success: false, error: 'Banco de dados não disponível' });
    }

    const sistema = String(req.query.sistema || '').trim().toUpperCase();
    const search = String(req.query.q || req.query.search || '').trim();
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);

    const filter = {};
    if (sistema) {
      filter.sistema = sistema;
    }

    if (search) {
      filter.$or = [
        { codigo: new RegExp(search, 'i') },
        { descricao: new RegExp(search, 'i') },
        { label: new RegExp(search, 'i') },
        { sinonimos: new RegExp(search, 'i') },
        { aliases: new RegExp(search, 'i') },
        { 'relacoes.cid': new RegExp(search, 'i') },
        { 'relacoes.cid10': new RegExp(search, 'i') },
        { 'relacoes.orpha': new RegExp(search, 'i') },
        { 'relacoes.omim': new RegExp(search, 'i') },
      ];
    }

    const terminologiesCollection = db.collection('terminologies');
    let [items, total] = await Promise.all([
      terminologiesCollection.find(filter).sort({ sistema: 1, codigo: 1 }).limit(limit).toArray(),
      terminologiesCollection.countDocuments(filter),
    ]);

    if (items.length === 0 && search) {
      const redundantRecords = await hydrateFromLocalRedundancy(db, { search, sistema, limit });
      if (redundantRecords.length > 0) {
        await bulkUpsertTerminologies(terminologiesCollection, redundantRecords);
        [items, total] = await Promise.all([
          terminologiesCollection.find(filter).sort({ sistema: 1, codigo: 1 }).limit(limit).toArray(),
          terminologiesCollection.countDocuments(filter),
        ]);
      }
    }

    if (items.length === 0 && search && (!sistema || sistema === 'ORPHA')) {
      const remoteRecords = await hydrateFromOrphadata(search, limit);
      if (remoteRecords.length > 0) {
        await bulkUpsertTerminologies(terminologiesCollection, remoteRecords);
        await bulkUpsertOrphanetRedundancy(db, remoteRecords);
        [items, total] = await Promise.all([
          terminologiesCollection.find(filter).sort({ sistema: 1, codigo: 1 }).limit(limit).toArray(),
          terminologiesCollection.countDocuments(filter),
        ]);
      }
    }

    res.json({
      success: true,
      data: items.map(formatTerminology),
      pagination: {
        total,
        limit,
      },
    });
  } catch (error) {
    logger.error(`Erro ao listar terminologias: ${error.message}`);
    res.status(500).json({ success: false, error: 'Erro ao listar terminologias' });
  }
});

router.post('/sync', async (req, res) => {
  try {
    const db = req.app.locals.db;
    if (!db) {
      return res.status(503).json({ success: false, error: 'Banco de dados não disponível para sincronização' });
    }
    const result = await syncFromOrphadata(db);
    res.json({ success: true, ...result });
  } catch (error) {
    logger.error(`Erro ao sincronizar terminologias: ${error.message}`);
    res.status(500).json({ success: false, error: 'Erro ao sincronizar terminologias' });
  }
});

module.exports = router;
