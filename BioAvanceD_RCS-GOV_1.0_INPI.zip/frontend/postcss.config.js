export default {
  plugins: {
    autoprefixer: {},
  },
};