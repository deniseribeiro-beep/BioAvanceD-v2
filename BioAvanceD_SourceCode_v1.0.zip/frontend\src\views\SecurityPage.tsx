import { useState, useEffect } from 'react';
import Card from '../components/UI/Card';
import Button from '../components/UI/Button';
import { Shield, Save, Download, AlertCircle, CheckCircle, Filter } from 'lucide-react';
import { useSecurity, SecurityConfig, ProfilePermissions } from '../hooks/useSecurity';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../components/UI/ToastContainer';
import './SecurityPage.css';

export default function SecurityPage() {
  const { user, isLoading: authLoading, hasRole } = useAuth();
  const { t } = useLanguage();
  const { showToast } = useToast();
  const { config, permissions, loading, error, saving, updateConfig, updatePermissions, exportLogs } = useSecurity();
  const [localConfig, setLocalConfig] = useState<SecurityConfig | null>(null);
  const [localPermissions, setLocalPermissions] = useState<ProfilePermissions | null>(null);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [activeSection, setActiveSection] = useState<string>('authentication');
  const [logFilters, setLogFilters] = useState({
    severity: '',
    module: '',
    startDate: '',
    endDate: ''
  });

  useEffect(() => {
    if (config) {
      setLocalConfig(config);
    }
  }, [config]);

  useEffect(() => {
    if (permissions) {
      setLocalPermissions(permissions);
    }
  }, [permissions]);

  // Aguarda carregamento do usuário antes de verificar
  if (authLoading) {
    return (
      <div className="security-page">
        <p>Carregando...</p>
      </div>
    );
  }

  // Verifica se o usuário é Administrador usando a função hasRole do AuthContext
  // que já faz o mapeamento correto de accessType para roleName
  const isAdmin = hasRole('Administrador') || user?.accessType === 4;
  
  // Log de debug em desenvolvimento
  useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      console.log('[SecurityPage] Verificação de admin:', {
        user,
        roleName: user?.roleName,
        accessType: user?.accessType,
        hasRoleAdmin: hasRole('Administrador'),
        isAdmin
      });
    }
  }, [user, hasRole, isAdmin]);

  if (!isAdmin) {
    return (
      <div className="security-page">
        <div className="access-denied">
          <AlertCircle size={48} />
          <h2>{t('security.accessDenied')}</h2>
          <p>{t('security.accessDeniedMessage')}</p>
        </div>
      </div>
    );
  }

  const handleConfigChange = (path: string, value: any) => {
    if (!localConfig) return;

    const keys = path.split('.');
    const newConfig = { ...localConfig };
    let current: any = newConfig;

    for (let i = 0; i < keys.length - 1; i++) {
      if (!current[keys[i]]) {
        current[keys[i]] = {};
      }
      current = current[keys[i]];
    }

    current[keys[keys.length - 1]] = value;
    setLocalConfig(newConfig);
  };

  const handlePermissionChange = (profile: string, permission: string, value: boolean) => {
    if (!localPermissions) return;

    const newPermissions = { ...localPermissions };
    if (!newPermissions[profile]) {
      newPermissions[profile] = {};
    }
    newPermissions[profile][permission] = value;
    setLocalPermissions(newPermissions);
  };

  const handleSaveConfig = async () => {
    if (!localConfig) return;

    try {
      await updateConfig(localConfig);
      setSaveStatus('success');
      showToast(t('security.saveSuccess'), 'success');
      setTimeout(() => setSaveStatus('idle'), 3000);
    } catch (err: any) {
      setSaveStatus('error');
      showToast(err.message || t('security.saveError'), 'error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  const handleSavePermissions = async () => {
    if (!localPermissions) return;

    try {
      await updatePermissions(localPermissions);
      setSaveStatus('success');
      showToast(t('security.permissions.saveSuccess'), 'success');
      setTimeout(() => setSaveStatus('idle'), 3000);
    } catch (err: any) {
      setSaveStatus('error');
      showToast(err.message || t('security.permissions.saveError'), 'error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  const handleExportLogs = async (format: 'csv' | 'json' = 'csv') => {
    try {
      const response = await exportLogs(logFilters, format);
      
      // Cria blob e faz download
      let blob: Blob;
      if (format === 'csv') {
        // Para CSV, response.data já é uma string
        blob = new Blob([response.data], { type: 'text/csv;charset=utf-8' });
      } else {
        // Para JSON, response.data é um array de objetos
        blob = new Blob([JSON.stringify(response.data, null, 2)], { type: 'application/json;charset=utf-8' });
      }
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `logs_${new Date().toISOString().split('T')[0]}.${format}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      showToast(t('security.logging.exportSuccess'), 'success');
    } catch (err: any) {
      showToast(err.message || t('security.exportError'), 'error');
    }
  };

  if (loading) {
    return (
      <div className="security-page">
        <p>{t('security.loading')}</p>
      </div>
    );
  }

  if (!localConfig || !localPermissions) {
    return (
      <div className="security-page">
        <p>{t('security.loadError')}</p>
      </div>
    );
  }

  const profileNames: Record<string, string> = {
    '1': t('roles.externalUser'),
    '2': t('roles.technician'),
    '3': t('roles.coordinator'),
    '4': t('roles.administrator')
  };

  return (
    <div className="security-page">
      <div className="security-header">
        <h1 className="security-title">
          <Shield size={32} /> {t('security.title')}
        </h1>
        <p className="security-subtitle">{t('security.subtitleFull')}</p>
      </div>

      {error && (
        <div className="security-error">
          <AlertCircle size={20} />
          <span>{error}</span>
        </div>
      )}

      {saveStatus === 'success' && (
        <div className="security-success">
          <CheckCircle size={20} />
          <span>{t('security.saveSuccess')}</span>
        </div>
      )}

      <div className="security-content">
        {/* Menu de Navegação Lateral */}
        <div className="security-sidebar">
          <nav className="security-nav">
            <button
              className={activeSection === 'authentication' ? 'active' : ''}
              onClick={() => setActiveSection('authentication')}
            >
              {t('security.sections.authentication')}
            </button>
            <button
              className={activeSection === 'password' ? 'active' : ''}
              onClick={() => setActiveSection('password')}
            >
              {t('security.sections.password')}
            </button>
            <button
              className={activeSection === 'session' ? 'active' : ''}
              onClick={() => setActiveSection('session')}
            >
              {t('security.sections.session')}
            </button>
            <button
              className={activeSection === 'login' ? 'active' : ''}
              onClick={() => setActiveSection('login')}
            >
              {t('security.sections.login')}
            </button>
            <button
              className={activeSection === 'logging' ? 'active' : ''}
              onClick={() => setActiveSection('logging')}
            >
              {t('security.sections.logging')}
            </button>
            <button
              className={activeSection === 'permissions' ? 'active' : ''}
              onClick={() => setActiveSection('permissions')}
            >
              {t('security.sections.permissions')}
            </button>
            <button
              className={activeSection === 'privacy' ? 'active' : ''}
              onClick={() => setActiveSection('privacy')}
            >
              {t('security.sections.privacy')}
            </button>
            <button
              className={activeSection === 'enhanced' ? 'active' : ''}
              onClick={() => setActiveSection('enhanced')}
            >
              {t('security.sections.enhanced')}
            </button>
            <button
              className={activeSection === 'lgpd' ? 'active' : ''}
              onClick={() => setActiveSection('lgpd')}
            >
              {t('security.sections.lgpd')}
            </button>
            <button
              className={activeSection === 'policies' ? 'active' : ''}
              onClick={() => setActiveSection('policies')}
            >
              {t('security.sections.policies')}
            </button>
          </nav>
        </div>

        {/* Conteúdo Principal */}
        <div className="security-main">
          {/* Seção: Autenticação e Acesso */}
          {activeSection === 'authentication' && (
            <Card className="security-section">
              <h2>{t('security.sections.authentication')}</h2>
              <div className="config-group">
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.authentication.requireMFA}
                    onChange={(e) => handleConfigChange('authentication.requireMFA', e.target.checked)}
                  />
                  <span>{t('security.authentication.requireMFA')}</span>
                </label>
                <div className="config-field">
                  <label>{t('security.authentication.mfaMethod')}</label>
                  <select
                    value={localConfig.authentication.mfaMethod}
                    onChange={(e) => handleConfigChange('authentication.mfaMethod', e.target.value)}
                  >
                    <option value="totp">{t('security.mfa.methodTotp')}</option>
                    <option value="sms">{t('security.mfa.methodSms')}</option>
                    <option value="email">{t('security.mfa.methodEmail')}</option>
                  </select>
                </div>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.authentication.requireStrongPassword}
                    onChange={(e) => handleConfigChange('authentication.requireStrongPassword', e.target.checked)}
                  />
                  <span>{t('security.authentication.requireStrongPassword')}</span>
                </label>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.authentication.allowPasswordReset}
                    onChange={(e) => handleConfigChange('authentication.allowPasswordReset', e.target.checked)}
                  />
                  <span>{t('security.authentication.allowPasswordReset')}</span>
                </label>
                <div className="config-field">
                  <label>{t('security.authentication.maxLoginAttempts')}</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={localConfig.authentication.maxLoginAttempts}
                    onChange={(e) => handleConfigChange('authentication.maxLoginAttempts', parseInt(e.target.value))}
                  />
                </div>
                <div className="config-field">
                  <label>{t('security.authentication.lockoutDuration')}</label>
                  <input
                    type="number"
                    min="1"
                    max="1440"
                    value={localConfig.authentication.lockoutDuration}
                    onChange={(e) => handleConfigChange('authentication.lockoutDuration', parseInt(e.target.value))}
                  />
                  <span className="config-help">{t('security.authentication.lockoutDurationHelp')}</span>
                </div>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.loginAttempts.trackIP}
                    onChange={(e) => handleConfigChange('loginAttempts.trackIP', e.target.checked)}
                  />
                  <span>{t('security.login.trackIP')}</span>
                </label>
                {localConfig.loginAttempts.trackIP && (
                  <div className="config-field">
                    <label>{t('security.login.blockIPAfterAttempts')}</label>
                    <input
                      type="number"
                      min="5"
                      max="100"
                      value={localConfig.loginAttempts.blockIPAfterAttempts}
                      onChange={(e) => handleConfigChange('loginAttempts.blockIPAfterAttempts', parseInt(e.target.value))}
                    />
                  </div>
                )}
              </div>
              <div className="config-actions">
                <Button onClick={handleSaveConfig} disabled={saving}>
                  <Save size={18} />
                  {saving ? t('users.saving') : t('common.save')}
                </Button>
              </div>
            </Card>
          )}

          {/* Seção: Regras de Senha */}
          {activeSection === 'password' && (
            <Card className="security-section">
              <h2>{t('security.sections.password')}</h2>
              <div className="config-group">
                <div className="config-field">
                  <label>{t('security.password.minLength')}</label>
                  <input
                    type="number"
                    min="6"
                    max="128"
                    value={localConfig.passwordRules.minLength}
                    onChange={(e) => handleConfigChange('passwordRules.minLength', parseInt(e.target.value))}
                  />
                </div>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.passwordRules.requireUppercase}
                    onChange={(e) => handleConfigChange('passwordRules.requireUppercase', e.target.checked)}
                  />
                  <span>{t('security.password.requireUppercase')}</span>
                </label>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.passwordRules.requireLowercase}
                    onChange={(e) => handleConfigChange('passwordRules.requireLowercase', e.target.checked)}
                  />
                  <span>{t('security.password.requireLowercase')}</span>
                </label>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.passwordRules.requireNumbers}
                    onChange={(e) => handleConfigChange('passwordRules.requireNumbers', e.target.checked)}
                  />
                  <span>{t('security.password.requireNumbers')}</span>
                </label>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.passwordRules.requireSpecialChars}
                    onChange={(e) => handleConfigChange('passwordRules.requireSpecialChars', e.target.checked)}
                  />
                  <span>{t('security.password.requireSpecialChars')}</span>
                </label>
                <div className="config-field">
                  <label>{t('security.password.expirationDays')}</label>
                  <input
                    type="number"
                    min="0"
                    max="365"
                    value={localConfig.passwordRules.expirationDays}
                    onChange={(e) => handleConfigChange('passwordRules.expirationDays', parseInt(e.target.value))}
                  />
                </div>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.passwordRules.preventReuse}
                    onChange={(e) => handleConfigChange('passwordRules.preventReuse', e.target.checked)}
                  />
                  <span>{t('security.password.preventReuse')}</span>
                </label>
                {localConfig.passwordRules.preventReuse && (
                  <div className="config-field">
                    <label>{t('security.password.maxReuseHistory')}</label>
                    <input
                      type="number"
                      min="1"
                      max="20"
                      value={localConfig.passwordRules.maxReuseHistory}
                      onChange={(e) => handleConfigChange('passwordRules.maxReuseHistory', parseInt(e.target.value))}
                    />
                  </div>
                )}
              </div>
              <div className="config-actions">
                <Button onClick={handleSaveConfig} disabled={saving}>
                  <Save size={18} />
                  {saving ? t('users.saving') : t('common.save')}
                </Button>
              </div>
            </Card>
          )}

          {/* Seção: Gerenciamento de Sessão */}
          {activeSection === 'session' && (
            <Card className="security-section">
              <h2>{t('security.sections.session')}</h2>
              <div className="config-group">
                <div className="config-field">
                  <label>{t('security.session.timeoutMinutes')}</label>
                  <input
                    type="number"
                    min="5"
                    max="480"
                    value={localConfig.session.timeoutMinutes}
                    onChange={(e) => handleConfigChange('session.timeoutMinutes', parseInt(e.target.value))}
                  />
                  <span className="config-help">{t('security.session.timeoutMinutesHelp')}</span>
                </div>
                <div className="config-field">
                  <label>{t('security.session.maxDuration')}</label>
                  <input
                    type="number"
                    min="1"
                    max="24"
                    value={localConfig.session.maxSessionDuration}
                    onChange={(e) => handleConfigChange('session.maxSessionDuration', parseInt(e.target.value))}
                  />
                  <span className="config-help">{t('security.session.maxDurationHelp')}</span>
                </div>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.session.allowMultipleSessions}
                    onChange={(e) => handleConfigChange('session.allowMultipleSessions', e.target.checked)}
                  />
                  <span>{t('security.session.allowMultipleSessions')}</span>
                </label>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.session.autoRenewal ?? true}
                    onChange={(e) => handleConfigChange('session.autoRenewal', e.target.checked)}
                  />
                  <span>{t('security.session.autoRenewal')}</span>
                </label>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.session.logExpiration ?? true}
                    onChange={(e) => handleConfigChange('session.logExpiration', e.target.checked)}
                  />
                  <span>{t('security.session.logExpiration')}</span>
                </label>
              </div>
              <div className="config-actions">
                <Button onClick={handleSaveConfig} disabled={saving}>
                  <Save size={18} />
                  {saving ? t('users.saving') : t('common.save')}
                </Button>
              </div>
            </Card>
          )}

          {/* Seção: Tentativas de Login */}
          {activeSection === 'login' && (
            <Card className="security-section">
              <h2>{t('security.login.title')}</h2>
              <div className="config-group">
                <div className="config-field">
                  <label>{t('security.login.maxAttempts')}</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={localConfig.loginAttempts.maxAttempts}
                    onChange={(e) => handleConfigChange('loginAttempts.maxAttempts', parseInt(e.target.value))}
                  />
                </div>
                <div className="config-field">
                  <label>{t('security.login.lockoutDuration')}</label>
                  <input
                    type="number"
                    min="1"
                    max="1440"
                    value={localConfig.loginAttempts.lockoutDuration}
                    onChange={(e) => handleConfigChange('loginAttempts.lockoutDuration', parseInt(e.target.value))}
                  />
                </div>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.loginAttempts.trackIP}
                    onChange={(e) => handleConfigChange('loginAttempts.trackIP', e.target.checked)}
                  />
                  <span>{t('security.login.trackIP')}</span>
                </label>
                {localConfig.loginAttempts.trackIP && (
                  <div className="config-field">
                    <label>{t('security.login.blockIPAfterAttempts')}</label>
                    <input
                      type="number"
                      min="5"
                      max="100"
                      value={localConfig.loginAttempts.blockIPAfterAttempts}
                      onChange={(e) => handleConfigChange('loginAttempts.blockIPAfterAttempts', parseInt(e.target.value))}
                    />
                  </div>
                )}
              </div>
              <div className="config-actions">
                <Button onClick={handleSaveConfig} disabled={saving}>
                  <Save size={18} />
                  {saving ? t('users.saving') : t('common.save')}
                </Button>
              </div>
            </Card>
          )}

          {/* Seção: Auditoria e Logs */}
          {activeSection === 'logging' && (
            <Card className="security-section">
              <h2>{t('security.sections.logging')}</h2>
              <div className="config-group">
                <div className="config-field">
                  <label>{t('security.logging.minLevel')}</label>
                  <select
                    value={localConfig.logging.level}
                    onChange={(e) => handleConfigChange('logging.level', e.target.value)}
                  >
                    <option value="info">{t('logs.severity.info')}</option>
                    <option value="warning">{t('logs.severity.warning')}</option>
                    <option value="error">{t('logs.severity.error')}</option>
                    <option value="critical">{t('logs.severity.critical')}</option>
                  </select>
                </div>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.logging.logLoginAttempts}
                    onChange={(e) => handleConfigChange('logging.logLoginAttempts', e.target.checked)}
                  />
                  <span>{t('security.logging.logLoginAttempts')}</span>
                </label>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.logging.logAllActions}
                    onChange={(e) => handleConfigChange('logging.logAllActions', e.target.checked)}
                  />
                  <span>{t('security.logging.logAllActions')}</span>
                </label>
                <div className="config-field">
                  <label>{t('security.logging.retentionDays')}</label>
                  <input
                    type="number"
                    min="30"
                    max="3650"
                    value={localConfig.logging.retentionDays}
                    onChange={(e) => handleConfigChange('logging.retentionDays', parseInt(e.target.value))}
                  />
                </div>
              </div>
              
              {/* Filtros de Exportação */}
              <div className="config-group config-group-divider">
                <h3 className="config-subtitle">{t('security.logging.exportFilters')}</h3>
                <div className="config-field">
                  <label>{t('security.logging.filterSeverity')}</label>
                  <select
                    value={logFilters.severity}
                    onChange={(e) => setLogFilters({ ...logFilters, severity: e.target.value })}
                  >
                    <option value="">{t('security.logging.allSeverities')}</option>
                    <option value="info">{t('logs.severity.info')}</option>
                    <option value="warning">{t('logs.severity.warning')}</option>
                    <option value="error">{t('logs.severity.error')}</option>
                    <option value="critical">{t('logs.severity.critical')}</option>
                  </select>
                </div>
                <div className="config-field">
                  <label>{t('security.logging.filterModule')}</label>
                  <input
                    type="text"
                    value={logFilters.module}
                    onChange={(e) => setLogFilters({ ...logFilters, module: e.target.value })}
                    placeholder={t('security.logging.filterModulePlaceholder')}
                  />
                </div>
                <div className="config-field">
                  <label>{t('security.logging.filterStartDate')}</label>
                  <input
                    type="date"
                    value={logFilters.startDate}
                    onChange={(e) => setLogFilters({ ...logFilters, startDate: e.target.value })}
                  />
                </div>
                <div className="config-field">
                  <label>{t('security.logging.filterEndDate')}</label>
                  <input
                    type="date"
                    value={logFilters.endDate}
                    onChange={(e) => setLogFilters({ ...logFilters, endDate: e.target.value })}
                  />
                </div>
              </div>
              
              <div className="config-actions">
                <Button onClick={handleSaveConfig} disabled={saving}>
                  <Save size={18} />
                  {saving ? t('users.saving') : t('common.save')}
                </Button>
                <Button variant="secondary" onClick={() => handleExportLogs('csv')}>
                  <Download size={18} />
                  {t('security.logging.exportCsv')}
                </Button>
                <Button variant="secondary" onClick={() => handleExportLogs('json')}>
                  <Download size={18} />
                  {t('security.logging.exportJson')}
                </Button>
              </div>
            </Card>
          )}

          {/* Seção: Permissões */}
          {activeSection === 'permissions' && (
            <Card className="security-section">
              <h2>{t('security.permissions.title')}</h2>
              <div className="permissions-grid">
                {Object.keys(localPermissions).map((profile) => (
                  <div key={profile} className="permission-profile">
                    <h3>{profileNames[profile] || t('security.permissions.profile').replace('{id}', profile)}</h3>
                    {Object.keys(localPermissions[profile]).map((permission) => (
                      <label key={permission} className="config-switch">
                        <input
                          type="checkbox"
                          checked={localPermissions[profile][permission] || false}
                          onChange={(e) => handlePermissionChange(profile, permission, e.target.checked)}
                        />
                        <span>{permission}</span>
                      </label>
                    ))}
                  </div>
                ))}
              </div>
              <div className="config-actions">
                <Button onClick={handleSavePermissions} disabled={saving}>
                  <Save size={18} />
                  {saving ? t('users.saving') : t('security.permissions.savePermissions')}
                </Button>
              </div>
            </Card>
          )}

          {/* Seção: Privacidade */}
          {activeSection === 'privacy' && (
            <Card className="security-section">
              <h2>{t('security.privacy.title')}</h2>
              <div className="config-group">
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.privacy.anonymizeLogs}
                    onChange={(e) => handleConfigChange('privacy.anonymizeLogs', e.target.checked)}
                  />
                  <span>{t('security.privacy.anonymizeLogs')}</span>
                </label>
                <div className="config-field">
                  <label>{t('security.privacy.dataRetentionDays')}</label>
                  <input
                    type="number"
                    min="30"
                    max="3650"
                    value={localConfig.privacy.dataRetentionDays}
                    onChange={(e) => handleConfigChange('privacy.dataRetentionDays', parseInt(e.target.value))}
                  />
                </div>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.privacy.autoPurge}
                    onChange={(e) => handleConfigChange('privacy.autoPurge', e.target.checked)}
                  />
                  <span>{t('security.privacy.autoPurge')}</span>
                </label>
                {localConfig.privacy.autoPurge && (
                  <>
                    <div className="config-field">
                      <label>{t('security.privacy.purgeAfterDays')}</label>
                      <input
                        type="number"
                        min="90"
                        max="3650"
                        value={localConfig.privacy.purgeAfterDays}
                        onChange={(e) => handleConfigChange('privacy.purgeAfterDays', parseInt(e.target.value))}
                      />
                    </div>
                    <div className="config-field">
                      <label>{t('security.privacy.anonymizeAfterDays')}</label>
                      <input
                        type="number"
                        min="30"
                        max="365"
                        value={localConfig.privacy.anonymizeAfterDays}
                        onChange={(e) => handleConfigChange('privacy.anonymizeAfterDays', parseInt(e.target.value))}
                      />
                    </div>
                  </>
                )}
              </div>
              <div className="config-actions">
                <Button onClick={handleSaveConfig} disabled={saving}>
                  <Save size={18} />
                  {saving ? t('users.saving') : t('common.save')}
                </Button>
              </div>
            </Card>
          )}

          {/* Seção: Modo Segurança Reforçado */}
          {activeSection === 'enhanced' && (
            <Card className="security-section">
              <h2>{t('security.enhanced.title')}</h2>
              <div className="config-group">
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.enhancedSecurity.enabled}
                    onChange={(e) => handleConfigChange('enhancedSecurity.enabled', e.target.checked)}
                  />
                  <span>{t('security.enhanced.enable')}</span>
                </label>
                {localConfig.enhancedSecurity.enabled && (
                  <>
                    <label className="config-switch">
                      <input
                        type="checkbox"
                        checked={localConfig.enhancedSecurity.requireMFAForAll}
                        onChange={(e) => handleConfigChange('enhancedSecurity.requireMFAForAll', e.target.checked)}
                      />
                      <span>{t('security.enhanced.requireMFAForAll')}</span>
                    </label>
                    <label className="config-switch">
                      <input
                        type="checkbox"
                        checked={localConfig.enhancedSecurity.strictPasswordPolicy}
                        onChange={(e) => handleConfigChange('enhancedSecurity.strictPasswordPolicy', e.target.checked)}
                      />
                      <span>{t('security.enhanced.strictPasswordPolicy')}</span>
                    </label>
                    <div className="config-field">
                      <label>{t('security.enhanced.sessionTimeoutMinutes')}</label>
                      <input
                        type="number"
                        min="5"
                        max="60"
                        value={localConfig.enhancedSecurity.sessionTimeoutMinutes}
                        onChange={(e) => handleConfigChange('enhancedSecurity.sessionTimeoutMinutes', parseInt(e.target.value))}
                      />
                    </div>
                    <label className="config-switch">
                      <input
                        type="checkbox"
                        checked={localConfig.enhancedSecurity.logAllActions}
                        onChange={(e) => handleConfigChange('enhancedSecurity.logAllActions', e.target.checked)}
                      />
                      <span>{t('security.enhanced.logAllActions')}</span>
                    </label>
                    <label className="config-switch">
                      <input
                        type="checkbox"
                        checked={localConfig.enhancedSecurity.blockUnusualActivity}
                        onChange={(e) => handleConfigChange('enhancedSecurity.blockUnusualActivity', e.target.checked)}
                      />
                      <span>{t('security.enhanced.blockUnusualActivity')}</span>
                    </label>
                  </>
                )}
              </div>
              <div className="config-actions">
                <Button onClick={handleSaveConfig} disabled={saving}>
                  <Save size={18} />
                  {saving ? t('users.saving') : t('common.save')}
                </Button>
              </div>
            </Card>
          )}

          {/* Seção: LGPD */}
          {activeSection === 'lgpd' && (
            <Card className="security-section">
              <h2>{t('security.lgpd.title')}</h2>
              <div className="config-group">
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.lgpd.allowDataExport}
                    onChange={(e) => handleConfigChange('lgpd.allowDataExport', e.target.checked)}
                  />
                  <span>{t('security.lgpd.allowDataExport')}</span>
                </label>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.lgpd.allowDataDeletion}
                    onChange={(e) => handleConfigChange('lgpd.allowDataDeletion', e.target.checked)}
                  />
                  <span>{t('security.lgpd.allowDataDeletion')}</span>
                </label>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.lgpd.anonymizeOnExport}
                    onChange={(e) => handleConfigChange('lgpd.anonymizeOnExport', e.target.checked)}
                  />
                  <span>{t('security.lgpd.anonymizeOnExport')}</span>
                </label>
                <label className="config-switch">
                  <input
                    type="checkbox"
                    checked={localConfig.lgpd.requireConsent}
                    onChange={(e) => handleConfigChange('lgpd.requireConsent', e.target.checked)}
                  />
                  <span>{t('security.lgpd.requireConsent')}</span>
                </label>
                {localConfig.lgpd.requireConsent && (
                  <div className="config-field">
                    <label>{t('security.lgpd.consentExpirationDays')}</label>
                    <input
                      type="number"
                      min="30"
                      max="3650"
                      value={localConfig.lgpd.consentExpirationDays}
                      onChange={(e) => handleConfigChange('lgpd.consentExpirationDays', parseInt(e.target.value))}
                    />
                  </div>
                )}
              </div>
              <div className="config-actions">
                <Button onClick={handleSaveConfig} disabled={saving}>
                  <Save size={18} />
                  {saving ? t('users.saving') : t('common.save')}
                </Button>
              </div>
            </Card>
          )}

          {/* Seção: Políticas e Diretrizes Técnicas */}
          {activeSection === 'policies' && (
            <div className="security-policies">
              <Card className="security-section">
                <h2>Políticas e Diretrizes de Segurança do Sistema</h2>
                <p className="policies-intro">
                  Este documento apresenta as diretrizes técnicas, políticas de segurança e requisitos de conformidade 
                  implementados no BioAdvanceD para proteção de dados sensíveis de saúde, em conformidade com a LGPD 
                  e boas práticas de segurança da informação.
                </p>
              </Card>

              {/* MFA Obrigatório */}
              <Card className="security-section">
                <h3>1. Autenticação Multifator (MFA) Obrigatória</h3>
                <div className="policy-content">
                  <h4>1.1. MFA TOTP no Primeiro Acesso</h4>
                  <ul>
                    <li><strong>Obrigatoriedade:</strong> Todo usuário deve ativar o Google Authenticator (TOTP) no primeiro login ao sistema.</li>
                    <li><strong>Bloqueio de Acesso:</strong> Enquanto o MFA TOTP não for configurado e validado, todo o acesso ao sistema permanece bloqueado, exceto a rota de configuração de MFA.</li>
                    <li><strong>Processo de Configuração:</strong>
                      <ul>
                        <li>Geração automática de QR Code com secret criptografado</li>
                        <li>Validação obrigatória do primeiro código TOTP (6 dígitos)</li>
                        <li>Registro seguro do secret criptografado no banco de dados</li>
                        <li>Ativação do MFA apenas após validação bem-sucedida</li>
                      </ul>
                    </li>
                    <li><strong>Método Primário:</strong> TOTP (Time-based One-Time Password) é o método MFA primário e obrigatório para todos os usuários.</li>
                  </ul>

                  <h4>1.2. Métodos Alternativos de MFA (Opcionais)</h4>
                  <p>Após o MFA primário estar ativo, o usuário pode cadastrar métodos de fallback:</p>
                  <ul>
                    <li><strong>Telefone/SMS:</strong> OTP com expiração curta (5 minutos) e número mascarado na exibição (ex: +55 (XX) XXXXX-XXXX)</li>
                    <li><strong>Passkey FIDO2/WebAuthn:</strong> Registro e validação de chave pública criptográfica para autenticação sem senha</li>
                    <li><strong>Recovery Codes:</strong> Códigos de recuperação criptografados, de uso único, gerados durante a configuração do MFA</li>
                  </ul>
                  <p><strong>Restrições:</strong> Métodos alternativos só podem ser removidos ou adicionados após autenticação completa (MFA primário + senha).</p>
                </div>
              </Card>

              {/* Política de Senha */}
              <Card className="security-section">
                <h3>2. Política de Senha (LGPD + Segurança Avançada)</h3>
                <div className="policy-content">
                  <h4>2.1. Requisitos de Complexidade</h4>
                  <ul>
                    <li><strong>Comprimento Mínimo:</strong> 12 caracteres (recomendado para sistemas de saúde)</li>
                    <li><strong>Complexidade Obrigatória:</strong>
                      <ul>
                        <li>Pelo menos uma letra maiúscula (A-Z)</li>
                        <li>Pelo menos uma letra minúscula (a-z)</li>
                        <li>Pelo menos um número (0-9)</li>
                        <li>Pelo menos um caractere especial ({'!@#$%^&*()_+-=[]{}|;:,.<>?'})</li>
                      </ul>
                    </li>
                    <li><strong>Verificação contra Senhas Vazadas:</strong> O sistema verifica senhas contra bases de dados conhecidas de senhas comprometidas (Have I Been Pwned API ou similar).</li>
                  </ul>

                  <h4>2.2. Expiração e Renovação</h4>
                  <ul>
                    <li><strong>Expiração Obrigatória:</strong> 90 dias (valor recomendado para sistemas de saúde segundo boas práticas)</li>
                    <li><strong>Bloqueio de Reutilização:</strong> Impede reutilização das últimas 5 senhas do histórico</li>
                    <li><strong>Troca Forçada:</strong> Após expiração, o usuário é forçado a trocar a senha imediatamente no próximo login</li>
                    <li><strong>Alerta Preventivo:</strong> Sistema exibe alerta ao usuário 10 dias antes da expiração da senha</li>
                  </ul>

                  <h4>2.3. Armazenamento Seguro</h4>
                  <ul>
                    <li><strong>Algoritmos Suportados:</strong> Argon2id (preferencial), bcrypt ou PBKDF2</li>
                    <li><strong>Salt Único:</strong> Cada senha utiliza salt único e aleatório</li>
                    <li><strong>Nunca em Texto Claro:</strong> Senhas nunca são armazenadas ou transmitidas em texto claro</li>
                  </ul>
                </div>
              </Card>

              {/* Fluxos de Recuperação */}
              <Card className="security-section">
                <h3>3. Fluxos de Recuperação Seguros</h3>
                <div className="policy-content">
                  <h4>3.1. Recuperação de Acesso MFA</h4>
                  <p>Caso o usuário perca o aplicativo TOTP, o sistema permite login alternativo através de:</p>
                  <ul>
                    <li><strong>Passkey FIDO2/WebAuthn:</strong> Se previamente cadastrado</li>
                    <li><strong>SMS/Telefone:</strong> Se método alternativo estiver ativo</li>
                    <li><strong>Recovery Codes:</strong> Códigos de recuperação de uso único</li>
                  </ul>

                  <h4>3.2. Reset de MFA</h4>
                  <ul>
                    <li><strong>Verificação Forte Obrigatória:</strong> Reset de MFA só pode ser realizado com verificação forte (nunca apenas por e-mail isolado)</li>
                    <li><strong>Métodos Aceitos:</strong> Verificação por outro método MFA ativo, recovery code ou confirmação por administrador com auditoria</li>
                    <li><strong>Bloqueio Temporário:</strong> Após reset, conta fica temporariamente bloqueada até nova configuração de MFA</li>
                  </ul>

                  <h4>3.3. Auditoria de Alterações</h4>
                  <ul>
                    <li><strong>Registro Obrigatório:</strong> Todas as alterações de segurança (MFA, senha, métodos alternativos) são registradas em logs de auditoria</li>
                    <li><strong>Dados Protegidos:</strong> Logs nunca contêm códigos MFA, senhas ou dados pessoais sensíveis</li>
                    <li><strong>Rastreabilidade:</strong> Cada alteração registra: usuário (anonimizado), timestamp, IP, user-agent e tipo de alteração</li>
                  </ul>
                </div>
              </Card>

              {/* LGPD e Privacidade */}
              <Card className="security-section">
                <h3>4. LGPD e Privacidade</h3>
                <div className="policy-content">
                  <h4>4.1. Criptografia de Dados</h4>
                  <ul>
                    <li><strong>Criptografia em Repouso:</strong> Todos os dados sensíveis são criptografados em repouso usando AES-256</li>
                    <li><strong>Criptografia em Trânsito:</strong> Todas as comunicações utilizam TLS 1.2+ (HTTPS obrigatório)</li>
                    <li><strong>Chaves de Criptografia:</strong> Gerenciadas de forma segura, com rotação periódica</li>
                  </ul>

                  <h4>4.2. Minimização e Necessidade</h4>
                  <ul>
                    <li><strong>Mascaramento de Dados:</strong> Telefones são exibidos apenas mascarados (ex: +55 (XX) XXXXX-XXXX)</li>
                    <li><strong>Proteção de Secrets:</strong> Secrets TOTP nunca são exibidos após a configuração inicial</li>
                    <li><strong>Princípio da Necessidade:</strong> Apenas dados estritamente necessários são coletados e processados</li>
                  </ul>

                  <h4>4.3. Logs e Anonimização</h4>
                  <ul>
                    <li><strong>Anonimização Automática:</strong> Logs são automaticamente anonimizados, utilizando identificadores únicos (userAnonId) em vez de dados pessoais</li>
                    <li><strong>Dados Excluídos dos Logs:</strong> Senhas, códigos MFA, números de documentos completos, endereços completos</li>
                    <li><strong>Retenção:</strong> Logs são mantidos conforme política de retenção configurável (padrão: 365 dias)</li>
                  </ul>

                  <h4>4.4. Princípios LGPD</h4>
                  <ul>
                    <li><strong>Segurança:</strong> Medidas técnicas e administrativas para proteção de dados</li>
                    <li><strong>Prevenção:</strong> Adoção de medidas para prevenir danos por tratamento de dados</li>
                    <li><strong>Responsabilização:</strong> Demonstração de conformidade e adoção de medidas eficazes</li>
                  </ul>

                  <h4>4.5. HTTPS e HSTS</h4>
                  <ul>
                    <li><strong>HTTPS Obrigatório:</strong> Força uso de HTTPS com HSTS (HTTP Strict Transport Security)</li>
                    <li><strong>Bloqueio de HTTP:</strong> Acesso por HTTP é bloqueado em produção</li>
                    <li><strong>Certificados Válidos:</strong> Utilização de certificados SSL/TLS válidos e atualizados</li>
                  </ul>
                </div>
              </Card>

              {/* Boas Práticas */}
              <Card className="security-section">
                <h3>5. Boas Práticas de Segurança</h3>
                <div className="policy-content">
                  <h4>5.1. Security Headers (Helmet.js)</h4>
                  <ul>
                    <li><strong>CSP (Content Security Policy):</strong> Define políticas de conteúdo permitidas, prevenindo XSS</li>
                    <li><strong>X-Frame-Options:</strong> Previne clickjacking (DENY ou SAMEORIGIN)</li>
                    <li><strong>X-Content-Type-Options:</strong> Força verificação de MIME type (nosniff)</li>
                    <li><strong>Referrer-Policy:</strong> Controla informações de referrer enviadas</li>
                    <li><strong>Permissions-Policy:</strong> Controla recursos do navegador (câmera, geolocalização, etc.)</li>
                  </ul>

                  <h4>5.2. Rate Limiting e Bloqueio</h4>
                  <ul>
                    <li><strong>Rate Limiting:</strong> Implementado em todas as rotas críticas (login, autenticação, alterações de segurança)</li>
                    <li><strong>Bloqueio por Tentativas:</strong> Após 5 tentativas inválidas de login, conta é bloqueada temporariamente (30 minutos)</li>
                    <li><strong>Bloqueio por IP:</strong> Após 10 tentativas inválidas do mesmo IP, bloqueio automático por 1 hora</li>
                    <li><strong>Rastreamento:</strong> Todas as tentativas são registradas para análise de segurança</li>
                  </ul>

                  <h4>5.3. CORS Restrito</h4>
                  <ul>
                    <li><strong>Origins Permitidas:</strong> CORS configurado apenas para domínios autorizados do sistema</li>
                    <li><strong>Credenciais:</strong> Credenciais (cookies, tokens) são enviadas apenas para origins permitidas</li>
                    <li><strong>Métodos Permitidos:</strong> Apenas métodos HTTP necessários (GET, POST, PUT, DELETE, PATCH)</li>
                  </ul>

                  <h4>5.4. Tokens JWT</h4>
                  <ul>
                    <li><strong>Rotação Periódica:</strong> Tokens JWT são rotacionados periodicamente (renovação por atividade)</li>
                    <li><strong>Expiração:</strong> Tokens expiram após 12 horas de inatividade ou 12 horas totais</li>
                    <li><strong>Assinatura Segura:</strong> Tokens são assinados com algoritmo HS256 e secret forte</li>
                    <li><strong>Validação Rigorosa:</strong> Todas as requisições validam assinatura e expiração do token</li>
                  </ul>

                  <h4>5.5. Verificação Anticlonagem</h4>
                  <ul>
                    <li><strong>Detecção de Sessões Suspeitas:</strong> Sistema detecta múltiplas sessões do mesmo usuário de IPs diferentes</li>
                    <li><strong>Alertas:</strong> Administradores são alertados sobre atividades suspeitas</li>
                    <li><strong>Bloqueio Preventivo:</strong> Sessões suspeitas podem ser bloqueadas automaticamente</li>
                  </ul>
                </div>
              </Card>

              {/* Painel do Usuário */}
              <Card className="security-section">
                <h3>6. Painel de Segurança do Usuário</h3>
                <div className="policy-content">
                  <p>O sistema disponibiliza um painel de segurança onde o usuário pode:</p>
                  <ul>
                    <li><strong>Status do MFA:</strong> Visualizar status de ativação e métodos configurados</li>
                    <li><strong>Expiração de Senha:</strong> Verificar data de expiração e dias restantes</li>
                    <li><strong>Logs Recentes:</strong> Acessar histórico de atividades de segurança (anonimizado)</li>
                    <li><strong>Métodos Alternativos:</strong> Cadastrar, visualizar e remover métodos MFA alternativos</li>
                    <li><strong>Reset Seguro:</strong> Solicitar reset de MFA ou senha com verificação forte</li>
                  </ul>
                </div>
              </Card>

              {/* Checklist de Conformidade */}
              <Card className="security-section">
                <h3>7. Checklist de Conformidade de Segurança</h3>
                <div className="policy-content">
                  <div className="compliance-checklist">
                    <div className="checklist-category">
                      <h4>✓ Autenticação e MFA</h4>
                      <ul className="checklist-items">
                        <li>☑ MFA TOTP obrigatório no primeiro acesso</li>
                        <li>☑ Bloqueio de acesso até configuração de MFA</li>
                        <li>☑ Geração e validação de QR Code TOTP</li>
                        <li>☑ Armazenamento seguro de secrets (criptografado)</li>
                        <li>☑ Métodos alternativos opcionais (SMS, Passkey, Recovery Codes)</li>
                        <li>☑ Reset de MFA com verificação forte</li>
                      </ul>
                    </div>

                    <div className="checklist-category">
                      <h4>✓ Política de Senha</h4>
                      <ul className="checklist-items">
                        <li>☑ Senha mínima de 12 caracteres</li>
                        <li>☑ Complexidade obrigatória (maiúsculas, minúsculas, números, especiais)</li>
                        <li>☑ Verificação contra senhas vazadas</li>
                        <li>☑ Expiração obrigatória a cada 90 dias</li>
                        <li>☑ Bloqueio de reutilização das últimas 5 senhas</li>
                        <li>☑ Troca forçada após expiração</li>
                        <li>☑ Alerta 10 dias antes da expiração</li>
                        <li>☑ Armazenamento com Argon2id/bcrypt/PBKDF2</li>
                      </ul>
                    </div>

                    <div className="checklist-category">
                      <h4>✓ Criptografia e Proteção de Dados</h4>
                      <ul className="checklist-items">
                        <li>☑ Criptografia AES-256 em repouso</li>
                        <li>☑ TLS 1.2+ para dados em trânsito</li>
                        <li>☑ HTTPS obrigatório com HSTS</li>
                        <li>☑ Bloqueio de acesso HTTP</li>
                        <li>☑ Mascaramento de dados sensíveis na exibição</li>
                        <li>☑ Minimização de dados coletados</li>
                      </ul>
                    </div>

                    <div className="checklist-category">
                      <h4>✓ Logs e Auditoria</h4>
                      <ul className="checklist-items">
                        <li>☑ Logs de auditoria para todas as alterações de segurança</li>
                        <li>☑ Anonimização automática de dados sensíveis nos logs</li>
                        <li>☑ Nunca registrar códigos MFA ou senhas</li>
                        <li>☑ Rastreabilidade completa (usuário anonimizado, timestamp, IP, user-agent)</li>
                        <li>☑ Retenção configurável de logs (padrão: 365 dias)</li>
                        <li>☑ Exportação de logs com filtros e anonimização</li>
                      </ul>
                    </div>

                    <div className="checklist-category">
                      <h4>✓ Security Headers e Proteções</h4>
                      <ul className="checklist-items">
                        <li>☑ Helmet.js configurado (CSP, X-Frame-Options, X-Content-Type-Options)</li>
                        <li>☑ Referrer-Policy configurado</li>
                        <li>☑ Permissions-Policy configurado</li>
                        <li>☑ Rate limiting em rotas críticas</li>
                        <li>☑ Bloqueio após tentativas inválidas</li>
                        <li>☑ CORS restrito a domínios autorizados</li>
                        <li>☑ Rotação periódica de tokens JWT</li>
                        <li>☑ Verificação anticlonagem de sessões</li>
                      </ul>
                    </div>

                    <div className="checklist-category">
                      <h4>✓ LGPD e Privacidade</h4>
                      <ul className="checklist-items">
                        <li>☑ Princípio de segurança implementado</li>
                        <li>☑ Princípio de prevenção implementado</li>
                        <li>☑ Princípio de responsabilização implementado</li>
                        <li>☑ Anonimização de dados em logs</li>
                        <li>☑ Mascaramento de dados sensíveis na interface</li>
                        <li>☑ Consentimento quando necessário</li>
                        <li>☑ Direito ao esquecimento (exclusão de dados)</li>
                        <li>☑ Portabilidade de dados (exportação anonimizada)</li>
                      </ul>
                    </div>

                    <div className="checklist-category">
                      <h4>✓ Recuperação e Resiliência</h4>
                      <ul className="checklist-items">
                        <li>☑ Recuperação de acesso via métodos alternativos</li>
                        <li>☑ Recovery codes criptografados e de uso único</li>
                        <li>☑ Reset seguro com verificação forte</li>
                        <li>☑ Backup regular e seguro de dados</li>
                        <li>☑ Plano de recuperação de desastres</li>
                        <li>☑ Monitoramento contínuo de segurança</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Informações Técnicas */}
              <Card className="security-section">
                <h3>8. Especificações Técnicas</h3>
                <div className="policy-content">
                  <h4>8.1. Algoritmos e Padrões Utilizados</h4>
                  <ul>
                    <li><strong>Hash de Senha:</strong> Argon2id (preferencial), bcrypt ou PBKDF2</li>
                    <li><strong>Criptografia:</strong> AES-256-GCM para dados em repouso</li>
                    <li><strong>TLS:</strong> TLS 1.2+ (recomendado TLS 1.3)</li>
                    <li><strong>JWT:</strong> HS256 com secret forte (mínimo 256 bits)</li>
                    <li><strong>TOTP:</strong> RFC 6238 (SHA-1, período de 30 segundos, 6 dígitos)</li>
                    <li><strong>FIDO2/WebAuthn:</strong> W3C Web Authentication API</li>
                  </ul>

                  <h4>8.2. Requisitos de Infraestrutura</h4>
                  <ul>
                    <li><strong>Servidor:</strong> Node.js 18+ com Express.js</li>
                    <li><strong>Banco de Dados:</strong> MongoDB com criptografia de conexão</li>
                    <li><strong>Certificados SSL/TLS:</strong> Válidos e atualizados</li>
                    <li><strong>Firewall:</strong> Configurado para permitir apenas tráfego necessário</li>
                    <li><strong>Monitoramento:</strong> Logs centralizados e análise de segurança</li>
                  </ul>
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

