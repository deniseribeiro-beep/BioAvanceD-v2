import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Bold,
  Clock3,
  FileDown,
  FileText,
  History,
  Italic,
  List,
  ListOrdered,
  Plus,
  Save,
  ShieldCheck,
  Sparkles,
  Type,
  Underline,
  X,
} from 'lucide-react';
import Card from '../components/UI/Card';
import Button from '../components/UI/Button';
import Input from '../components/UI/Input';
import Spinner from '../components/UI/Spinner';
import { useToast } from '../components/UI/ToastContainer';
import { consentService } from '../services/api';
import type { ConsentTemplate, ConsentPolicy } from '../types/models';
import './TcleBuilderPage.css';

type PreviewValueMap = Record<string, string>;

type ConsentItemDraft = {
  id: string;
  label: string;
  required: boolean;
};

const PREVIEW_VALUES: PreviewValueMap = {
  titulo_projeto: 'Projeto BioAvanceD - Biobanco Genômico',
  nome_pesquisador: 'Dra. Marina Silva',
  numero_caae: '12345678.9.0000.0000',
  nome_participante: 'João Carlos da Silva',
  id_paciente_sistema: 'PAC-00012345',
  id_amostra: 'SAM-00067890',
};

const FIXED_HEADER_TEMPLATE = `PROJETO: {{titulo_projeto}}
PESQUISADOR: {{nome_pesquisador}} | CAAE: {{numero_caae}}
PARTICIPANTE: {{nome_participante}} | ID PACIENTE: {{id_paciente_sistema}} | ID AMOSTRA: {{id_amostra}}`;

const FIXED_CONSENT_DECLARATION = 'Eu, {{nome_participante}}, declaro que fui devidamente esclarecido(a) e concordo voluntariamente em participar deste estudo, nos termos apresentados neste documento.';

const FIXED_SIGNATURE_PARTICIPANT = 'Assinatura de {{nome_participante}}';
const FIXED_SIGNATURE_RESEARCHER = 'Assinatura de {{nome_pesquisador}}';

const DEFAULT_BODY_HTML = `
  <p>Este termo descreve os objetivos do estudo, os riscos, os benefícios esperados e as condições de tratamento das informações coletadas.</p>
  <p>Use este corpo para detalhar riscos, benefícios e metodologia. O cabeçalho e as assinaturas abaixo são renderizados pelo sistema como elementos fixos do documento.</p>
`;

function createId() {
  return globalThis.crypto?.randomUUID?.() || `tcle-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function replaceProtectedTags(html: string, values: PreviewValueMap) {
  return String(html || '').replace(/\{\{\s*([a-z_]+)\s*\}\}/gi, (_match, rawKey) => {
    const key = String(rawKey || '').toLowerCase();
    const replacement = values[key];
    if (!replacement) {
      return `{{${key}}}`;
    }
    return escapeHtml(replacement);
  });
}

function stripHtml(html: string) {
  return String(html || '')
    .replace(/<br\s*\/?\>/gi, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeTitle(value: string) {
  return String(value || '').trim().toLowerCase();
}

function slugify(value: string) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

function pad(value: number) {
  return String(value).padStart(2, '0');
}

function toDateInputValue(value?: Date | string | null) {
  if (!value) {
    return '';
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return '';
  }

  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function toIsoDateString(value: string, endOfDay = false) {
  if (!value) {
    return '';
  }

  const suffix = endOfDay ? '23:59:59.999' : '12:00:00.000';
  return new Date(`${value}T${suffix}`).toISOString();
}

function getHtmlContent(policy?: ConsentPolicy | null) {
  if (!policy) {
    return DEFAULT_BODY_HTML.trim();
  }

  return String(policy.htmlContent || '').trim() || DEFAULT_BODY_HTML.trim();
}

function unwrapSingleResponse(response: any) {
  return response?.data?.data ?? response?.data ?? null;
}

function unwrapListResponse(response: any) {
  const payload = response?.data?.data ?? response?.data ?? null;
  if (Array.isArray(payload)) {
    return payload;
  }

  if (Array.isArray(payload?.items)) {
    return payload.items;
  }

  return [];
}

function createDraftItem(label = '', required = false): ConsentItemDraft {
  return {
    id: createId(),
    label,
    required,
  };
}

function normalizeDraftItems(items: Array<Partial<ConsentItemDraft> | null | undefined>) {
  const normalized = (Array.isArray(items) ? items : [])
    .map((item) => ({
      id: createId(),
      label: String(item?.label || '').trim(),
      required: Boolean(item?.required),
    }))
    .filter((item) => item.label.length > 0);

  return normalized.length > 0 ? normalized : [createDraftItem()];
}

function normalizeGranularPermissions(items: ConsentItemDraft[]) {
  const usedKeys = new Set<string>();

  function hashKey(str: string) {
    // Simple hash: djb2
    let hash = 5381;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) + hash) + str.charCodeAt(i);
    }
    return Math.abs(hash).toString(36).slice(0, 8); // 8 chars max
  }

  return items
    .map((item, index) => {
      const label = String(item.label || '').trim();
      if (!label) {
        return null;
      }

      const hash = hashKey(label);
      let key = `consent_${hash}`;
      let suffix = 2;

      while (usedKeys.has(key)) {
        key = `consent_${hash}_${suffix}`;
        suffix += 1;
      }

      usedKeys.add(key);

      return {
        key,
        label,
        required: Boolean(item.required),
      };
    })
    .filter(Boolean) as Array<{ key: string; label: string; required: boolean }>;
}

function parseVersionNumber(version: string) {
  const match = String(version || '').match(/(\d+)/);
  return match ? Number(match[1]) : 0;
}

function formatDate(value?: Date | string | null) {
  const date = value ? new Date(value) : null;
  if (!date || Number.isNaN(date.getTime())) {
    return '--';
  }

  return date.toLocaleDateString('pt-BR');
}

function getErrorMessage(error: any, fallback: string) {
  return error?.response?.data?.message || error?.response?.data?.error || error?.message || fallback;
}

function buildPrintablePolicyHtml(policy: ConsentPolicy) {
  const headerHtml = replaceProtectedTags(FIXED_HEADER_TEMPLATE, PREVIEW_VALUES);
  const acceptanceHtml = replaceProtectedTags(FIXED_CONSENT_DECLARATION, PREVIEW_VALUES);
  const participantSignatureHtml = replaceProtectedTags(FIXED_SIGNATURE_PARTICIPANT, PREVIEW_VALUES);
  const researcherSignatureHtml = replaceProtectedTags(FIXED_SIGNATURE_RESEARCHER, PREVIEW_VALUES);
  const bodyHtml = replaceProtectedTags(String(policy.htmlContent || '').trim() || DEFAULT_BODY_HTML.trim(), PREVIEW_VALUES);
  const granularPermissions = Array.isArray(policy.granularPermissions) ? policy.granularPermissions : [];
  const printableTitle = escapeHtml(`${policy.version || 'v?'} - ${policy.title || 'TCLE'}`);

  return `<!doctype html>
  <html lang="pt-BR">
    <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <title>${printableTitle}</title>
      <style>
        * { box-sizing: border-box; }
        body {
          margin: 0;
          padding: 24px;
          font-family: Arial, Helvetica, sans-serif;
          color: #0f172a;
          background: #f8fafc;
        }
        .sheet {
          max-width: 820px;
          margin: 0 auto;
          background: #fff;
          border: 1px solid #e2e8f0;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
        }
        .block { padding: 24px; }
        .fixed {
          background: #f1f5f9;
          border-top: 1px solid #e2e8f0;
          border-bottom: 1px solid #e2e8f0;
        }
        .eyebrow {
          display: inline-block;
          margin-bottom: 14px;
          padding: 4px 10px;
          border-radius: 999px;
          background: #e2e8f0;
          color: #334155;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .static-text {
          margin: 0;
          white-space: pre-line;
          line-height: 1.75;
          font-size: 14px;
          color: #0f172a;
        }
        .title {
          margin: 0 0 10px 0;
          font-size: 24px;
        }
        .body { line-height: 1.75; font-size: 15px; }
        .body p { margin: 0 0 12px 0; }
        .body h2, .body h3 { margin: 20px 0 10px 0; }
        .consent-list {
          margin-top: 20px;
          padding: 18px 20px;
          border: 1px solid #e2e8f0;
          border-radius: 14px;
          background: #f8fafc;
          page-break-inside: avoid;
        }
        .consent-list h4 {
          margin: 0 0 12px 0;
          font-size: 15px;
          font-weight: 700;
        }
        .consent-list ul {
          margin: 0;
          padding-left: 22px;
        }
        .consent-list li {
          margin-bottom: 10px;
          font-size: 14px;
          line-height: 1.7;
          word-break: break-word;
        }
        .acceptance-note {
          margin: 0;
          line-height: 1.75;
          font-size: 15px;
        }
        .signature-grid {
          display: grid;
          gap: 18px;
          margin-top: 20px;
        }
        .signature-line {
          min-height: 76px;
          display: grid;
          align-content: end;
          gap: 10px;
          color: #475569;
          font-size: 14px;
        }
        .signature-line::before {
          content: '';
          display: block;
          border-top: 1px solid #94a3b8;
        }
        .signature-line span {
          display: block;
          padding-top: 8px;
          color: #475569;
        }
        @page { size: A4; margin: 18mm; }
      </style>
    </head>
    <body>
      <article class="sheet">
        <section class="block fixed">
          <div class="eyebrow">Cabeçalho fixo</div>
          <pre class="static-text">${headerHtml}</pre>
        </section>
        <section class="block">
          <div class="eyebrow">Bloco editável</div>
          <div class="body">${bodyHtml}</div>
          ${granularPermissions.length > 0 ? `
            <div class="consent-list">
              <h4>Consentimentos granulares</h4>
              <ul>
                ${granularPermissions.map((permission) => `<li>${permission.required ? '[x]' : '[ ]'} ${escapeHtml(permission.label)}</li>`).join('')}
              </ul>
            </div>
          ` : ''}
        </section>
        <section class="block fixed">
          <div class="eyebrow">Aceite e assinaturas</div>
          <p class="acceptance-note">${acceptanceHtml}</p>
          <div class="signature-grid">
            <div class="signature-line"><span>${participantSignatureHtml}</span></div>
            <div class="signature-line"><span>${researcherSignatureHtml}</span></div>
          </div>
        </section>
      </article>
      <script>
        window.addEventListener('load', () => {
          window.setTimeout(() => {
            window.print();
          }, 150);
        });

        window.addEventListener('afterprint', () => {
          window.close();
        });
      </script>
    </body>
  </html>`;
}

function openPrintablePolicy(policy: ConsentPolicy) {
  const html = buildPrintablePolicyHtml(policy);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const blobUrl = URL.createObjectURL(blob);
  const printFrame = document.createElement('iframe');

  printFrame.style.position = 'fixed';
  printFrame.style.right = '0';
  printFrame.style.bottom = '0';
  printFrame.style.width = '0';
  printFrame.style.height = '0';
  printFrame.style.border = '0';
  printFrame.style.opacity = '0';
  printFrame.setAttribute('aria-hidden', 'true');
  printFrame.src = blobUrl;

  const cleanup = () => {
    try {
      URL.revokeObjectURL(blobUrl);
    } catch {
      // Ignora falhas de limpeza.
    }

    if (printFrame.parentNode) {
      printFrame.parentNode.removeChild(printFrame);
    }
  };

  printFrame.onload = () => {
    const frameWindow = printFrame.contentWindow;
    if (!frameWindow) {
      cleanup();
      return;
    }

    const triggerPrint = () => {
      try {
        frameWindow.focus();
        frameWindow.print();
      } catch {
        cleanup();
      }
    };

    frameWindow.addEventListener('afterprint', cleanup, { once: true });
    window.setTimeout(triggerPrint, 300);
  };

  document.body.appendChild(printFrame);
}

function defaultConsentItems() {
  return [createDraftItem()];
}

export default function TcleBuilderPage() {
  const { templateId } = useParams<{ templateId?: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const editorRef = useRef<HTMLDivElement | null>(null);
  const isEditing = Boolean(templateId);

  const [activeTab, setActiveTab] = useState<'editor' | 'history'>('editor');
  const [title, setTitle] = useState('');
  const [caae, setCaae] = useState('');
  const [validFrom, setValidFrom] = useState('');
  const [validTo, setValidTo] = useState('');
  const [bodyHtml, setBodyHtml] = useState(DEFAULT_BODY_HTML.trim());
  const [consentItems, setConsentItems] = useState<ConsentItemDraft[]>(() => defaultConsentItems());
  const [loadingTemplate, setLoadingTemplate] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loadedTemplate, setLoadedTemplate] = useState<ConsentTemplate | null>(null);
  const [historyAnchorTitle, setHistoryAnchorTitle] = useState('');
  const [historyGroupId, setHistoryGroupId] = useState('');
  const [historyItems, setHistoryItems] = useState<ConsentPolicy[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState('');
  const [editorReady, setEditorReady] = useState(false);

  const normalizedBody = useMemo(() => stripHtml(bodyHtml), [bodyHtml]);
  const currentModelTitle = useMemo(() => normalizeTitle(historyAnchorTitle || title), [historyAnchorTitle, title]);
  const granularPermissionsPreview = useMemo(() => normalizeGranularPermissions(consentItems), [consentItems]);
  const activeHistoryEntry = useMemo(() => historyItems.find((item) => item.active) || historyItems[0] || null, [historyItems]);
  const versionSummary = useMemo(() => ({
    total: historyItems.length,
    active: historyItems.filter((item) => item.active).length,
    obsolete: historyItems.filter((item) => !item.active).length,
  }), [historyItems]);

  useEffect(() => {
    const editor = editorRef.current;
    if (!editor) {
      return;
    }

    const nextHtml = bodyHtml || DEFAULT_BODY_HTML.trim();
    if (editor.innerHTML !== nextHtml) {
      editor.innerHTML = nextHtml;
    }
    // Set default text alignment to justified
    editor.style.textAlign = 'justify';
  }, [bodyHtml, editorReady]);

  useEffect(() => {
    let active = true;

    const loadTemplate = async () => {
      if (!templateId) {
        if (!active) {
          return;
        }

        setLoadedTemplate(null);
        setTitle('');
          setCaae('');
          setValidFrom('');
          setValidTo('');
        setBodyHtml(DEFAULT_BODY_HTML.trim());
        setConsentItems(defaultConsentItems());
        setHistoryAnchorTitle('');
        setHistoryGroupId('');
        setLoadingTemplate(false);
        return;
      }

      setLoadingTemplate(true);
      try {
        const response = await consentService.getTemplateById(templateId);
        const template = unwrapSingleResponse(response) as ConsentTemplate | null;

        if (!active) {
          return;
        }

        if (!template) {
          throw new Error('TCLE não encontrado para edição.');
        }

        setLoadedTemplate(template);
        setTitle(String(template.title || ''));
        setCaae(String(template.caae || ''));
        setValidFrom(toDateInputValue(template.validFrom || null));
        setValidTo(toDateInputValue(template.validTo || null));
        setBodyHtml(String(template.htmlContent || template.content || DEFAULT_BODY_HTML.trim()));
        setConsentItems(normalizeDraftItems(template.granularPermissions || template.permissions || []));
        setHistoryAnchorTitle(String(template.title || ''));
        setHistoryGroupId(''); // ConsentTemplate may not have versionGroupId
      } catch (error: any) {
        if (!active) {
          return;
        }

        showToast(getErrorMessage(error, 'Não foi possível carregar o TCLE selecionado.'), 'error');
        navigate('/admin/tcle/new', { replace: true });
      } finally {
        if (active) {
          setLoadingTemplate(false);
        }
      }
    };

    void loadTemplate();

    return () => {
      active = false;
    };
  }, [navigate, showToast, templateId]);

  useEffect(() => {
    let active = true;
    const query = currentModelTitle;
    const groupId = historyGroupId.trim();

    if (!query && !groupId) {
      setHistoryItems([]);
      setHistoryError('');
      setHistoryLoading(false);
      return () => {
        active = false;
      };
    }

    const timer = window.setTimeout(() => {
      void (async () => {
        setHistoryLoading(true);
        setHistoryError('');
        try {
          // For templates, just fetch all and filter by title
          const response = await consentService.getActiveTemplate();
          const template = unwrapSingleResponse(response) as ConsentTemplate | null;
          const normalizedQuery = normalizeTitle(query);
          const filtered = template && normalizeTitle(template.title) === normalizedQuery ? [template] : [];
          if (active) {
            setHistoryItems(filtered as any);
          }
        } catch (error: any) {
          if (active) {
            setHistoryItems([]);
            setHistoryError(error?.message || 'Não foi possível carregar o histórico de versões.');
          }
        } finally {
          if (active) {
            setHistoryLoading(false);
          }
        }
      })();
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [currentModelTitle]);

  const updateEditorState = () => {
    const editor = editorRef.current;
    if (!editor) {
      return;
    }

    setBodyHtml(editor.innerHTML);
  };

  const applyFormat = (command: string, value?: string) => {
    const editor = editorRef.current;
    if (!editor) {
      return;
    }

    editor.focus();
    document.execCommand(command, false, value);
    updateEditorState();
  };

  const addConsentItem = () => {
    setConsentItems((current) => [...current, createDraftItem()]);
  };

  const updateConsentItem = (id: string, patch: Partial<ConsentItemDraft>) => {
    setConsentItems((current) => current.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  };

  const removeConsentItem = (id: string) => {
    setConsentItems((current) => {
      const nextItems = current.filter((item) => item.id !== id);
      return nextItems.length > 0 ? nextItems : [createDraftItem()];
    });
  };


  const openPrintableView = (policy: ConsentPolicy) => {
    if (!policy?._id) {
      showToast('Não foi possível abrir a visualização em PDF.', 'warning');
      return;
    }

    if (typeof window === 'undefined' || typeof document === 'undefined') {
      showToast('O navegador bloqueou a visualização em PDF.', 'warning');
      return;
    }

    openPrintablePolicy(policy);
  };

  const handleSave = async () => {
    const trimmedTitle = title.trim();
    const normalizedBodyText = stripHtml(bodyHtml);

    if (!trimmedTitle || !validFrom || !validTo || !normalizedBodyText) {
      showToast('Preencha o nome do modelo, as datas de vigência e o corpo do termo antes de salvar.', 'warning');
      return;
    }

    if (new Date(`${validTo}T12:00:00.000`).getTime() < new Date(`${validFrom}T12:00:00.000`).getTime()) {
      showToast('A data final de vigência deve ser maior ou igual à data inicial.', 'warning');
      return;
    }

    const normalizedPermissions = normalizeGranularPermissions(consentItems);
    if (normalizedPermissions.length === 0) {
      showToast('Adicione ao menos um consentimento granular antes de salvar.', 'warning');
      return;
    }

    const payload = {
      title: trimmedTitle,
      caae: caae.trim(),
      htmlContent: bodyHtml.trim(),
      content: bodyHtml.trim(), // Ensure 'content' is sent for backend validation
      validFrom: toIsoDateString(validFrom),
      validTo: toIsoDateString(validTo, true),
      active: true,
      permissions: normalizedPermissions,
    };

    if (!payload.validFrom || !payload.validTo) {
      showToast('Data de vigência inválida.', 'warning');
      return;
    }

    setSaving(true);
    try {
      const response = isEditing && templateId
        ? await consentService.updateTemplate(templateId, payload)
        : await consentService.createTemplate(payload);

      const savedTemplate = unwrapSingleResponse(response) as ConsentTemplate | null;
      if (!savedTemplate || !savedTemplate._id) {
        throw new Error('O servidor não retornou a nova versão do TCLE.');
      }

      setLoadedTemplate(savedTemplate);
      setTitle(String(savedTemplate.title || trimmedTitle));
      setCaae(String(savedTemplate.caae || caae));
      setValidFrom(toDateInputValue(savedTemplate.validFrom || null));
      setValidTo(toDateInputValue(savedTemplate.validTo || null));
      setBodyHtml(String(savedTemplate.htmlContent || savedTemplate.content || DEFAULT_BODY_HTML.trim()));
      setConsentItems(normalizeDraftItems(savedTemplate.granularPermissions || savedTemplate.permissions || []));
      setHistoryAnchorTitle(String(savedTemplate.title || trimmedTitle));
      setHistoryGroupId('');

      if (editorRef.current) {
        editorRef.current.innerHTML = String(savedTemplate.htmlContent || savedTemplate.content || DEFAULT_BODY_HTML.trim());
      }

      showToast(
        isEditing ? 'Nova versão criada e a anterior foi desativada.' : 'TCLE criado com sucesso.',
        'success'
      );

      navigate(`/admin/tcle/edit/${savedTemplate._id}`, { replace: true });
    } catch (error: any) {
      showToast(getErrorMessage(error, 'Não foi possível salvar o TCLE.'), 'error');
    } finally {
      setSaving(false);
    }
  };

  const activeStatusLabel = activeHistoryEntry?.active ? 'Ativo' : 'Obsoleto';

  return (
    <div className="page tcle-builder-page">
      <div className="page-header tcle-builder-page__header">
        <div className="tcle-builder-page__heading">
          <div className="tcle-builder-page__eyebrow">
            <Sparkles size={15} />
            <span>Health Tech TCLE Builder</span>
          </div>
          <h1 className="page-title">Create and Edit ICF</h1>
          <p className="page-subtitle">
            Structure the consent form in a single column, with fixed header and acceptance, editable body, and manually filled validity dates.
          </p>
          <div className="tcle-builder-page__status-row">
            <span className="tcle-builder-page__status-pill">
              <History size={14} />
              {versionSummary.total > 0 ? `${versionSummary.total} versão(ões)` : 'Sem histórico ainda'}
            </span>
            <span className="tcle-builder-page__status-pill">
              <Clock3 size={14} />
              Vigência inicial {validFrom ? formatDate(validFrom) : '--'}
            </span>
            <span className="tcle-builder-page__status-pill">
              <ShieldCheck size={14} />
              {activeStatusLabel}
            </span>
          </div>
        </div>

      </div>

      <div className="tcle-builder-tabs" role="tablist" aria-label="Navegação do construtor de TCLE">
        {activeTab === 'editor' ? (
          <button
            type="button"
            role="tab"
            aria-selected="true"
            className="tcle-builder-tab is-active"
            onClick={() => setActiveTab('editor')}
          >
            <FileText size={16} />
            Edit Form
          </button>
        ) : (
          <button
            type="button"
            role="tab"
            aria-selected="false"
            className="tcle-builder-tab"
            onClick={() => setActiveTab('editor')}
          >
            <FileText size={16} />
            Edição do Termo
          </button>
        )}
        {activeTab === 'history' ? (
          <button
            type="button"
            role="tab"
            aria-selected="true"
            className="tcle-builder-tab is-active"
            onClick={() => setActiveTab('history')}
          >
            <History size={16} />
            Version History
          </button>
        ) : (
          <button
            type="button"
            role="tab"
            aria-selected="false"
            className="tcle-builder-tab"
            onClick={() => setActiveTab('history')}
          >
            <History size={16} />
            Histórico de Versões
          </button>
        )}
      </div>

      {activeTab === 'editor' ? (
        <form id="tcle-builder-form" className="tcle-builder-grid" onSubmit={(event) => { event.preventDefault(); void handleSave(); }}>
          <Card className="tcle-builder-card tcle-builder-card--editor-panel">
            <div className="tcle-builder-form-grid">
              <Input
                label="Nome do Modelo"
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="Ex.: TCLE Biobanco Genômico"
                helperText="Identifica a família documental que será versionada."
              />
              <Input
                label="CAAE"
                value={caae}
                onChange={(event) => setCaae(event.target.value)}
                placeholder="Ex.: 12345678.9.0000.0000"
                helperText="Informe o número CAAE associado a esta versão do TCLE."
              />
              <Input
                label="Data de Início da Vigência"
                type="date"
                value={validFrom}
                onChange={(event) => setValidFrom(event.target.value)}
                helperText="Preenchimento manual. Não existe cálculo automático."
              />
              <Input
                label="Data Final de Vigência"
                type="date"
                value={validTo}
                onChange={(event) => setValidTo(event.target.value)}
                helperText="Defina manualmente a data final do documento."
              />
            </div>

            <div className="tcle-builder-page__meta-strip tcle-builder-page__meta-strip--single-row">
              <div>
                <span>Versão ativa</span>
                <strong>{activeHistoryEntry?.version || 'v1'}</strong>
              </div>
              <div>
                <span>CAAE</span>
                <strong>{caae.trim() || activeHistoryEntry?.caae || '--'}</strong>
              </div>
              <div>
                <span>Itens granulares</span>
                <strong>{granularPermissionsPreview.length}</strong>
              </div>
              <div>
                <span>Corpo</span>
                <strong>{normalizedBody ? `${normalizedBody.length} caracteres` : 'Vazio'}</strong>
              </div>
              <div>
                <span>Modo</span>
                <strong>{isEditing ? 'Edição versionada' : 'Criação da 1ª versão'}</strong>
              </div>
            </div>

            <p className="tcle-builder-document-note">
              O sistema renderiza o cabeçalho e o termo de aceite como blocos fixos. Apenas o corpo explicativo e os consentimentos granulares ficam editáveis.
            </p>

            <div className="tcle-builder-document-shell">
              <section className="tcle-builder-document-block tcle-builder-document-block--fixed">
                <div className="tcle-builder-document-block__eyebrow">Bloco 1 - Cabeçalho fixo</div>
                <div className="tcle-builder-document-block__static tcle-builder-document-block__static--locked">
                  <pre className="tcle-builder-document-block__pre">{FIXED_HEADER_TEMPLATE}</pre>
                </div>
              </section>

              <section className="tcle-builder-document-block">
                <div className="tcle-builder-document-block__header">
                  <div>
                    <div className="tcle-builder-document-block__eyebrow">Bloco 2 - Corpo explicativo</div>
                    <h2>Corpo do Termo</h2>
                  </div>
                  <span className="tcle-builder-status-badge tcle-builder-status-badge--interactive">Rich Text</span>
                </div>

                <div className="tcle-builder-toolbar" role="toolbar" aria-label="Ferramentas do editor de TCLE">
                  <Button type="button" variant="secondary" className="btn-small btn-ghost" onMouseDown={(event) => event.preventDefault()} onClick={() => applyFormat('bold')}>
                    <Bold size={14} />
                    Negrito
                  </Button>
                  <Button type="button" variant="secondary" className="btn-small btn-ghost" onMouseDown={(event) => event.preventDefault()} onClick={() => applyFormat('italic')}>
                    <Italic size={14} />
                    Itálico
                  </Button>
                  <Button type="button" variant="secondary" className="btn-small btn-ghost" onMouseDown={(event) => event.preventDefault()} onClick={() => applyFormat('underline')}>
                    <Underline size={14} />
                    Sublinhado
                  </Button>
                  <Button type="button" variant="secondary" className="btn-small btn-ghost" onMouseDown={(event) => event.preventDefault()} onClick={() => applyFormat('insertUnorderedList')}>
                    <List size={14} />
                    Lista
                  </Button>
                  <Button type="button" variant="secondary" className="btn-small btn-ghost" onMouseDown={(event) => event.preventDefault()} onClick={() => applyFormat('insertOrderedList')}>
                    <ListOrdered size={14} />
                    Lista numerada
                  </Button>
                  <Button type="button" variant="secondary" className="btn-small btn-ghost" onMouseDown={(event) => event.preventDefault()} onClick={() => applyFormat('formatBlock', 'h2')}>
                    <Type size={14} />
                    Título
                  </Button>
                </div>

                <div
                  ref={editorRef}
                  className="tcle-builder-editor"
                  contentEditable
                  suppressContentEditableWarning
                  role="textbox"
                  aria-multiline="true"
                  aria-label="Editor do corpo do TCLE"
                  onInput={updateEditorState}
                  onBlur={updateEditorState}
                  onFocus={() => setEditorReady(true)}
                  style={{ textAlign: 'justify' }}
                />
              </section>

              <section className="tcle-builder-document-block">
                <div className="tcle-builder-document-block__header">
                  <div>
                    <div className="tcle-builder-document-block__eyebrow">Bloco 3 - Consentimentos granulares</div>
                    <h2>Itens de Aceite</h2>
                  </div>
                  <Button type="button" variant="secondary" className="btn-small" onClick={addConsentItem}>
                    <Plus size={14} />
                    Adicionar consentimento
                  </Button>
                </div>

                <div className="tcle-builder-consent-list">
                  {consentItems.map((item, index) => {
                    const hashKey = (str: string) => {
                      let hash = 5381;
                      for (let i = 0; i < str.length; i++) {
                        hash = ((hash << 5) + hash) + str.charCodeAt(i);
                      }
                      return Math.abs(hash).toString(36).slice(0, 8);
                    };
                    const generatedKey = item.label ? `consent_${hashKey(item.label)}` : `consent_item_${index + 1}`;

                    return (
                      <div key={item.id} className="tcle-builder-consent-item">
                        <div className="tcle-builder-consent-item__main">
                          <div className="tcle-builder-consent-item__field">
                            <label htmlFor={`consent-label-${item.id}`}>Texto do consentimento</label>
                            <input
                              id={`consent-label-${item.id}`}
                              value={item.label}
                              onChange={(event) => updateConsentItem(item.id, { label: event.target.value })}
                              placeholder="Ex.: Aceito ceder minhas amostras para estudos genéticos"
                            />
                            <span className="tcle-builder-consent-item__meta">Chave automática: {generatedKey}</span>
                          </div>
                          <label className="tcle-builder-consent-item__toggle">
                            <input
                              type="checkbox"
                              checked={item.required}
                              onChange={(event) => updateConsentItem(item.id, { required: event.target.checked })}
                            />
                            Checkbox obrigatório
                          </label>
                        </div>

                        <Button type="button" variant="secondary" className="btn-small btn-ghost tcle-builder-consent-item__remove" onClick={() => removeConsentItem(item.id)}>
                          <X size={14} />
                          Remover item
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </section>

              <section className="tcle-builder-document-block tcle-builder-document-block--fixed">
                <div className="tcle-builder-document-block__eyebrow">Bloco 4 - Aceite e assinaturas</div>
                <div className="tcle-builder-document-block__static tcle-builder-document-block__static--locked">
                  <p className="tcle-builder-document-block__static-text">{FIXED_CONSENT_DECLARATION}</p>
                  <div className="tcle-builder-signature-block">
                    <div className="tcle-builder-signature-line">
                      <span>___________________________________________________</span>
                      <strong>{FIXED_SIGNATURE_PARTICIPANT}</strong>
                    </div>
                    <div className="tcle-builder-signature-line">
                      <span>___________________________________________________</span>
                      <strong>{FIXED_SIGNATURE_RESEARCHER}</strong>
                    </div>
                  </div>
                </div>
              </section>
            </div>

            {loadingTemplate ? (
              <div className="tcle-builder-loading tcle-builder-loading--single">
                <Spinner size="sm" />
                <span>Carregando TCLE...</span>
              </div>
            ) : null}

            <div className="tcle-builder-document-actions">
              <Button
                variant="primary"
                type="submit"
                disabled={saving || loadingTemplate || !title.trim() || !validFrom || !validTo || !normalizedBody || granularPermissionsPreview.length === 0}
              >
                {saving ? <Spinner size="sm" /> : <Save size={16} />}
                {saving ? 'Salvando versão...' : isEditing ? 'Salvar nova versão do TCLE' : 'Criar versão do TCLE'}
              </Button>
            </div>
          </Card>
        </form>
      ) : (
        <div className="tcle-builder-history-layout">
          <Card className="tcle-builder-card tcle-builder-card--history">
            <div className="tcle-builder-section-header tcle-builder-section-header--stacked">
              <div>
                <h2>Version History</h2>
                <p>Only versions of the same model are shown. Each new edition creates a new record and deactivates the previous one.</p>
              </div>
              <div className="tcle-builder-history-summary">
                <span>
                  <strong>{versionSummary.total}</strong>
                  total
                </span>
                <span>
                  <strong>{versionSummary.active}</strong>
                  active
                </span>
                <span>
                  <strong>{versionSummary.obsolete}</strong>
                  obsolete
                </span>
              </div>
            </div>

            {historyLoading ? (
              <div className="tcle-builder-loading tcle-builder-loading--table">
                <Spinner size="sm" />
                <span>Carregando histórico...</span>
              </div>
            ) : null}

            {historyError ? <div className="tcle-builder-history-error">{historyError}</div> : null}

            {!historyLoading && !historyError && historyItems.length === 0 ? (
              <div className="tcle-builder-history-empty">
                <History size={22} />
                <strong>Nenhuma versão encontrada para este modelo.</strong>
                <span>Salve a primeira versão ou selecione um TCLE já versionado para ver o histórico.</span>
              </div>
            ) : null}

            {historyItems.length > 0 ? (
              <div className="tcle-builder-table-wrap">
                <table className="tcle-builder-table">
                  <thead>
                    <tr>
                      <th>Version</th>
                      <th>CAAE</th>
                      <th>Validity Date</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {historyItems.map((item) => (
                      <tr key={item._id}>
                        <td>
                          <strong>{item.version || '--'}</strong>
                        </td>
                        <td>{String(item.caae || '--').trim() || '--'}</td>
                        <td>{formatDate(item.validFrom)}</td>
                        <td>
                          <span className={`tcle-builder-status-badge tcle-builder-status-badge--${item.active ? 'active' : 'obsolete'}`}>
                            {item.active ? 'Active' : 'Obsolete'}
                          </span>
                        </td>
                        <td>
                          <div className="tcle-builder-table-actions">
                            <Button type="button" variant="secondary" className="btn-small" onClick={() => openPrintableView(item)}>
                              <FileDown size={14} />
                              PDF
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : null}
          </Card>

        </div>
      )}

    </div>
  );
}
